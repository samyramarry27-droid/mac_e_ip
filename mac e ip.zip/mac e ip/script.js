const perguntas = [
  {
    pergunta: 'Qual é a principal função do endereço MAC?',
    opcoes: [
      'Identificar o hardware da placa de rede',
      'Definir o endereço da internet',
      'Substituir o DNS',
      'Criptografar a conexão'
    ],
    correta: 0
  },
  {
    pergunta: 'Qual formato é normalmente usado para representar um MAC?',
    opcoes: [
      'IPv4',
      'Hexadecimal com dois pontos',
      'Decimal com traços',
      'Base64'
    ],
    correta: 1
  },
  {
    pergunta: 'O endereço IP é usado principalmente para:',
    opcoes: [
      'Identificar o dispositivo físico na placa',
      'Localizar o aparelho dentro da rede ou internet',
      'Armazenar dados temporários',
      'Trocar a senha da rede'
    ],
    correta: 1
  },
  {
    pergunta: 'Qual é um exemplo de endereço IPv4?',
    opcoes: ['08:00:27:AB:CD:EF', '2001:db8::1', '192.168.0.10', 'AA:BB:CC:DD:EE:FF'],
    correta: 2
  },
  {
    pergunta: 'Qual das afirmações abaixo está correta?',
    opcoes: [
      'MAC e IP são a mesma coisa',
      'MAC muda a cada conexão e IP é fixo',
      'MAC identifica o hardware e IP identifica a localização lógica',
      'IP só funciona em cabos Ethernet'
    ],
    correta: 2
  },
  {
    pergunta: 'Qual destes endereços é um exemplo de IPv6?',
    opcoes: ['10.0.0.1', '172.16.0.5', '2001:db8::10', '255.255.255.0'],
    correta: 2
  },
  {
    pergunta: 'O endereço MAC normalmente é atribuído por:',
    opcoes: [
      'A fabricante da placa de rede',
      'O provedor de internet',
      'O sistema operacional apenas no login',
      'O roteador da rede'
    ],
    correta: 0
  },
  {
    pergunta: 'Qual função do IP na comunicação entre redes?',
    opcoes: [
      'Garantir a identificação física do dispositivo',
      'Permitir o roteamento e a entrega lógica dos dados',
      'Criar a conexão Wi-Fi',
      'Bloquear pacotes suspeitos'
    ],
    correta: 1
  },
  {
    pergunta: 'Em uma mesma rede local, o MAC é mais útil para:',
    opcoes: [
      'Roteamento entre provedores',
      'Comunicação direta entre dispositivos na mesma LAN',
      'Identificar o domínio DNS',
      'Configurar a máscara de sub-rede'
    ],
    correta: 1
  }
];

const questionBox = document.getElementById('questionBox');
const optionsBox = document.getElementById('optionsBox');
const feedbackMessage = document.getElementById('feedbackMessage');
const timerLabel = document.getElementById('timerLabel');
const scoreLabel = document.getElementById('scoreLabel');
const progressBar = document.getElementById('progressBar');
const resultScreen = document.getElementById('resultScreen');
const quizScreen = document.getElementById('quizScreen');
const resultText = document.getElementById('resultText');
const restartBtn = document.getElementById('restartBtn');

let indiceAtual = 0;
let pontuacao = 0;
let tempo = 45;
let timerId;
let bloqueado = false;

function iniciarQuiz() {
  indiceAtual = 0;
  pontuacao = 0;
  tempo = 45;
  bloqueado = false;
  resultScreen.classList.add('hidden');
  quizScreen.classList.remove('hidden');
  feedbackMessage.textContent = '';
  feedbackMessage.className = 'feedback-message';
  scoreLabel.textContent = 'Pontuação: 0';
  progressBar.style.width = '0%';
  exibirPergunta();
  controleDeTempo();
}

function exibirPergunta() {
  const atual = perguntas[indiceAtual];
  questionBox.textContent = `${indiceAtual + 1}. ${atual.pergunta}`;
  optionsBox.innerHTML = '';
  atual.opcoes.forEach((texto, index) => {
    const button = document.createElement('button');
    button.className = 'option-btn';
    button.textContent = texto;
    button.addEventListener('click', () => validarResposta(index));
    optionsBox.appendChild(button);
  });
  timerLabel.textContent = `Tempo: ${tempo}s`;
  const progresso = ((indiceAtual + 1) / perguntas.length) * 100;
  progressBar.style.width = `${progresso}%`;
}

function validarResposta(index) {
  if (bloqueado) return;

  bloqueado = true;
  clearInterval(timerId);

  const correta = perguntas[indiceAtual].correta;
  const botoes = optionsBox.querySelectorAll('.option-btn');

  botoes.forEach((btn, i) => {
    btn.disabled = true;
    if (i === correta) btn.classList.add('correct');
    if (i === index && i !== correta) btn.classList.add('wrong');
  });

  if (index === correta) {
    pontuacao += 1;
    scoreLabel.textContent = `Pontuação: ${pontuacao}`;
    feedbackMessage.textContent = 'Resposta correta!';
    feedbackMessage.classList.add('correct');
  } else {
    feedbackMessage.textContent = 'Resposta incorreta. A resposta certa foi destacada.';
    feedbackMessage.classList.add('wrong');
  }

  setTimeout(() => {
    proximaPergunta();
  }, 900);
}

function controleDeTempo() {
  clearInterval(timerId);
  tempo = 45;
  timerLabel.textContent = `Tempo: ${tempo}s`;

  timerId = setInterval(() => {
    tempo -= 1;
    timerLabel.textContent = `Tempo: ${tempo}s`;

    if (tempo <= 0) {
      clearInterval(timerId);
      feedbackMessage.textContent = 'Tempo esgotado! A resposta correta foi destacada.';
      feedbackMessage.classList.add('wrong');
      bloquearRespostaAutomatica();
      setTimeout(() => {
        proximaPergunta();
      }, 900);
    }
  }, 1000);
}

function bloquearRespostaAutomatica() {
  bloqueado = true;
  const botoes = optionsBox.querySelectorAll('.option-btn');
  const correta = perguntas[indiceAtual].correta;
  botoes.forEach((btn, i) => {
    btn.disabled = true;
    if (i === correta) btn.classList.add('correct');
  });
}

function proximaPergunta() {
  indiceAtual += 1;
  if (indiceAtual >= perguntas.length) {
    calcularPontuacao();
    return;
  }

  bloqueado = false;
  feedbackMessage.textContent = '';
  feedbackMessage.className = 'feedback-message';
  exibirPergunta();
  controleDeTempo();
}

function calcularPontuacao() {
  clearInterval(timerId);
  quizScreen.classList.add('hidden');
  resultScreen.classList.remove('hidden');

  const total = perguntas.length;
  let mensagem = 'Revise o conteúdo';
  if (pontuacao === total) mensagem = 'Excelente!';
  else if (pontuacao >= 3) mensagem = 'Bom trabalho';

  resultText.textContent = `Você fez ${pontuacao}/${total}. ${mensagem}`;
}

restartBtn.addEventListener('click', iniciarQuiz);

iniciarQuiz();
